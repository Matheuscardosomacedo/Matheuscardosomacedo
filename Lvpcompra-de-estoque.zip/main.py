def main():
    
    
    
#declaraçao das variáveis
    
  qtda = float(0.0)
  qtdmx = float(0.0)
  qtdmi = float(0.0)
    
  #entrada de dados
  qtda = float(input())
  qtdmx = float(input())
  qtdmi = float(input())
    
  #processamento de dados
    
  qtdme = ((qtdmx + qtdmi)/2)
    
  if ( qtdme >= qtda):
   
      print ('NÃO EFETUAR COMPRA')
        
  else:
      print ('EFETUAR COMPRA')
    
  #saida de dados
    
  return 0
    
    
if __name__ == "__main__":
     main()
     
     